package com.eljavi.mascotas.model;

import android.content.ContentValues;
import android.content.Context;

import com.eljavi.mascotas.R;
import com.eljavi.mascotas.db.BaseDatos;
import com.eljavi.mascotas.db.ConstantesBaseDatos;

import java.util.ArrayList;

//Interactor
public class ConstructorMascotas {

    private static final int LIKE = 1;
    private Context context;

    //CONSTRUCTOR
    public ConstructorMascotas(Context context) {
        this.context = context;
    }

    public ArrayList<Mascotas> obtenerMascotas(){

        BaseDatos db = new BaseDatos(context);
        insertarMascotas(db);
        return db.obtenerTodosMascotas();


        /*
        ArrayList<Mascotas> mascotas = new ArrayList<>();
        mascotas.add(new Mascotas("Firulas", 4, R.drawable.perro_blanconegro));
        mascotas.add(new Mascotas("Garfield", 5, R.drawable.gato_garfield));
        mascotas.add(new Mascotas("Solovino", 7, R.drawable.perro_doberman));
        mascotas.add(new Mascotas("Killer", 4, R.drawable.perro_sabueso));
        mascotas.add(new Mascotas("Garras", 3, R.drawable.gato_gris));
        mascotas.add(new Mascotas("Pirata", 11, R.drawable.gato_pirata));
        return mascotas;
        */


    }

    public void insertarMascotas(BaseDatos db){
/*
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Firulais");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.perro_blanconegro);

        db.insertarMascota(contentValues);

        contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Garfield");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.gato_garfield);

        db.insertarMascota(contentValues);

        contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Solovino");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.perro_doberman);

        db.insertarMascota(contentValues);

        contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Killer");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.perro_sabueso);

        db.insertarMascota(contentValues);

        contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Garras");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.gato_gris);

        db.insertarMascota(contentValues);

        contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Pirata");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.gato_pirata);

        db.insertarMascota(contentValues);
*/
    }

    public void darLikeMascota(Mascotas mascotas){

        BaseDatos db = new BaseDatos((context));
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_LIKES_MASCOTAS_ID_MASCOTA, mascotas.getId());
        contentValues.put(ConstantesBaseDatos.TABLE_LIKES_NUMERO_LIKES, LIKE);

        db.insertarLikeMascota(contentValues);
    }

    public int obtenerLikeMascota(Mascotas mascota){
        BaseDatos db = new BaseDatos(context);
        return db.obtenerLikesMascotas(mascota);
    }



}






































