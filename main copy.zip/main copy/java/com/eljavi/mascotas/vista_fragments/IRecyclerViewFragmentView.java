package com.eljavi.mascotas.vista_fragments;

import com.eljavi.mascotas.adapter.MascotaAdaptador;
import com.eljavi.mascotas.model.Mascotas;

import java.util.ArrayList;

public interface IRecyclerViewFragmentView {

    public void generarLinearLayoutVertical();

    public MascotaAdaptador crearAdaptador(ArrayList<Mascotas> mascotas);

    public void inicializarAdaptadorRV(MascotaAdaptador adaptador);



}
