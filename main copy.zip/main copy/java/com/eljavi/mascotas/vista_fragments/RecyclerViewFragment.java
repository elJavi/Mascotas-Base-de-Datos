package com.eljavi.mascotas.vista_fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.eljavi.mascotas.R;
import com.eljavi.mascotas.adapter.MascotaAdaptador;
import com.eljavi.mascotas.model.Mascotas;
import com.eljavi.mascotas.presentador.IRecyclerViewFragmentPresenter;
import com.eljavi.mascotas.presentador.RecyclerViewFragmentPresenter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class RecyclerViewFragment extends Fragment implements IRecyclerViewFragmentView {

    private ArrayList<Mascotas> mascotas;
    private RecyclerView rvMascotas;
    public FloatingActionButton actionButton;
    private IRecyclerViewFragmentPresenter presenter;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_recycler_view, container, false);

        actionButton = (FloatingActionButton) v.findViewById(R.id.actionButton);
        //actionButton.setVisibility(View.VISIBLE);

        //Antes del fragm=ent esto estaba en el MainActivity
        rvMascotas = (RecyclerView) v.findViewById(R.id.rvMascotas);
        presenter = new RecyclerViewFragmentPresenter(this, getContext());
        return v;
    }

/*
    public void inicializarListaMascotas(){
        mascotas = new ArrayList<>();

        mascotas.add(new Mascotas("Firulas", 4, R.drawable.perro_blanconegro));
        mascotas.add(new Mascotas("Garfield", 5, R.drawable.gato_garfield));
        mascotas.add(new Mascotas("Solovino", 7, R.drawable.perro_doberman));
        mascotas.add(new Mascotas("Killer", 4, R.drawable.perro_sabueso));
        mascotas.add(new Mascotas("Garras", 3, R.drawable.gato_gris));
        mascotas.add(new Mascotas("Pirata", 11, R.drawable.gato_pirata));
    }

 */

    //METODOS DE LA INTERFAZ

    @Override
    public void generarLinearLayoutVertical() {
        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);

        //La lista de mascotas (RecyclerView se debe comportar como un linearLayoutManager
        rvMascotas.setLayoutManager(llm);
    }

    @Override
    public MascotaAdaptador crearAdaptador(ArrayList<Mascotas> mascotas) {
        MascotaAdaptador adaptador = new MascotaAdaptador(mascotas, getActivity());
        return adaptador;
    }

    @Override
    public void inicializarAdaptadorRV(MascotaAdaptador adaptador) {
        rvMascotas.setAdapter(adaptador);
    }
}
