package com.eljavi.mascotas.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.eljavi.mascotas.model.ConstructorMascotas;
import com.eljavi.mascotas.model.Mascotas;
import com.eljavi.mascotas.R;

import java.util.ArrayList;

//RECYCLER VIEW ADAPTER

public class MascotaAdaptador extends RecyclerView.Adapter<MascotaAdaptador.MascotaViewHolder>{  /////////////////////////////////////////////CLASE ADAPTER

    ArrayList<Mascotas> mascotas;
    Activity activity;
    Integer numero;


    public MascotaAdaptador(ArrayList<Mascotas> mascotas, Activity activity){
        this.mascotas = mascotas;
        this.activity = activity;
    }

    @NonNull
    @Override    //Infla el layout y lo pasa al viewholder para que obtenga los viewa
    public MascotaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        //Asocia el layout a nuestro Recycler View
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_mascotas, parent, false);

        return new MascotaViewHolder(v);
    }

    //Aqui se va a estar pasando la lista de mascotas. Asocia cada elemento de la lista con cada view
    @Override
    public void onBindViewHolder(@NonNull MascotaViewHolder mascotaViewHolder, int position) {

        final Mascotas mascota = mascotas.get(position);
        mascotaViewHolder.imgFoto.setImageResource(mascota.getFoto());
        mascotaViewHolder.tvNombre.setText(mascota.getNombre());
        mascotaViewHolder.tvLikes.setText(String.valueOf(mascota.getLikes()) + " Likes" ); //likes es entero asi que se debe convertir a string

        //Accion para el boton  Likes equivalente en esta app
        mascotaViewHolder.imgLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(activity, "Te gusta " + mascota.getNombre(), Toast.LENGTH_SHORT).show();
                //mascotaViewHolder.tvLikes.setText(String.valueOf(mascota.getLikes()+1));

                //INSERTAR LIKE EN BASE DE DATOS
                ConstructorMascotas constructorMascotas = new ConstructorMascotas(activity);
                constructorMascotas.darLikeMascota(mascota);

                mascotaViewHolder.tvLikes.setText(constructorMascotas.obtenerLikeMascota(mascota) + " " + activity.getString(R.string.likes));
            }
        });
    }

    @Override
    public int getItemCount() { //Cantidad de elementos que contiene la lista
        return mascotas.size();
    }

    //Clase anidada donde se declaran los views
    public static class MascotaViewHolder extends RecyclerView.ViewHolder{      //////////////////////////////////////////CLASE VIEWHOLDER

        private ImageView imgFoto;
        private ImageView imgLike;
        private TextView tvNombre;
        private TextView tvLikes;


        public MascotaViewHolder(@NonNull View itemView) {
            super(itemView);
            imgFoto         = (ImageView) itemView.findViewById((R.id.imgFoto));
            imgLike  = (ImageView) itemView.findViewById((R.id.like));
            tvNombre        = (TextView) itemView.findViewById((R.id.tvNombre));
            tvLikes         = (TextView) itemView.findViewById((R.id.tvLikes));
            //imgHuesoRojo    = (ImageView) itemView.findViewById(R.id.imgHuesoRojo);
        }
    }

}
