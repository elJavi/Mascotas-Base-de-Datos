package com.eljavi.mascotas.presentador;

public interface IRecyclerViewFragmentPresenter {

    public void obtenerMascotasBaseDatos();

    public void mostrarMascotasRV();


}
